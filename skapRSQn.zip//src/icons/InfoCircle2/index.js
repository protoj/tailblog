export { InfoCircle2 } from "./InfoCircle2";
