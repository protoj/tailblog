export { EyeAlt3 } from "./EyeAlt3";
